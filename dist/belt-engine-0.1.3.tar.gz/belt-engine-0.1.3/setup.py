# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['belt_engine']

package_data = \
{'': ['*'],
 'belt_engine': ['bin/*',
                 'bin/armLinux/*',
                 'bin/armLinux/lib/*',
                 'bin/linux/*',
                 'bin/linux/lib/*',
                 'bin/windows/*',
                 'resources/definitions/*',
                 'settings/*']}

install_requires = \
['Shapely==1.7.0',
 'numpy>=1.20.3,<2.0.0',
 'triangle>=20200424,<20200425',
 'trimesh[easy]>=3.9.19,<4.0.0']

entry_points = \
{'console_scripts': ['belt-engine = belt_engine.BeltEngine:main']}

setup_kwargs = {
    'name': 'belt-engine',
    'version': '0.1.3',
    'description': 'A commandline slicer for belt-style printers utilising CuraEngine',
    'long_description': None,
    'author': 'Michael Molinari',
    'author_email': 'mike@autodrop3d.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
